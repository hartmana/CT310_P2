</main>
<footer>
	<p>2015 © Copyright Group 7</p>
</footer>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://www.cs.colostate.edu/~ct310/yr2015sp/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>